#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Download public GP/OMM orbits for Starlink Gen1 / OneWeb / GSO.

No invented orbital elements. Python >=3.9 standard library only.

Examples:
    python download_three_constellations.py --output-dir .
    python download_three_constellations.py --output-dir . --starlink-omm starlink.json --oneweb-omm oneweb.json --geo-omm geo.json --starlink-index starindex.html
    python download_three_constellations.py --output-dir . --no-network --starlink-omm starlink.json --oneweb-omm oneweb.json --geo-omm geo.json --starlink-index starindex.html
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import sys
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
INDEX_URL = 'https://www.planet4589.org/space/con/star/starindex.html'
URLS = {
    'STARLINK': [
      'https://celestrak.org/NORAD/elements/gp.php?GROUP=STARLINK&FORMAT=JSON',
      'https://raw.githubusercontent.com/satvisorcom/satvisor-data/master/celestrak/json/starlink.json'],
    'ONEWEB': [
      'https://celestrak.org/NORAD/elements/gp.php?GROUP=ONEWEB&FORMAT=JSON',
      'https://raw.githubusercontent.com/satvisorcom/satvisor-data/master/celestrak/json/oneweb.json'],
    'GEO': [
      'https://celestrak.org/NORAD/elements/gp.php?GROUP=GEO&FORMAT=JSON',
      'https://raw.githubusercontent.com/satvisorcom/satvisor-data/master/celestrak/json/geo.json']
}
REQUIRED = ('OBJECT_NAME','OBJECT_ID','NORAD_CAT_ID','EPOCH','MEAN_MOTION',
            'ECCENTRICITY','INCLINATION','RA_OF_ASC_NODE','ARG_OF_PERICENTER',
            'MEAN_ANOMALY','BSTAR','MEAN_MOTION_DOT','MEAN_MOTION_DDOT')

class StarlinkIndexParser(HTMLParser):
    """Read first two cells from each satellite row of the JSR name index."""
    def __init__(self):
        super().__init__();self.rows=[];self.row=None;self.cell=None
    def handle_starttag(self,tag,attrs):
        if tag=='tr':self.row=[]
        if tag in ('td','th') and self.row is not None:self.cell=[]
    def handle_data(self,data):
        if self.cell is not None:self.cell.append(data)
    def handle_endtag(self,tag):
        if tag in ('td','th') and self.cell is not None:
            self.row.append(' '.join(''.join(self.cell).split()));self.cell=None
        if tag=='tr' and self.row is not None:
            if self.row:self.rows.append(self.row)
            self.row=None

def extract_gen1_index(html):
    parser=StarlinkIndexParser();parser.feed(html)
    versions={}
    for row in parser.rows:
        if len(row)<2:continue
        version=re.search(r'\bV1\.(0|5)\b',row[0],re.I)
        name=re.fullmatch(r'Starlink[\s-]+(\d{3,6})',row[1],re.I)
        if version and name:versions[int(name.group(1))]='V1.'+version.group(1)
    if len(versions)<2400:
        raise ValueError(f'JSR Gen1身份索引仅解析 {len(versions)} 条，拒绝用轨道倾角猜测身份。')
    return versions

def load_local(path):
    with open(path,encoding='utf-8-sig') as f:return json.load(f)

def request(url):
    req=Request(url,headers={'User-Agent':'ResearchFeederLinkGP/1.2','Accept':'application/json,text/html;q=0.9,*/*;q=0.8'})
    with urlopen(req,timeout=90) as r:return r.read()

def acquire(group,path,offline):
    if path:
        p=Path(path);r=load_local(p)
        return r,{'url':p.resolve().as_uri(),'retrieval':'local file'}
    if offline:raise RuntimeError(f'--no-network 需要提供 --{group.lower()}-omm 输入文件')
    errs=[]
    for url in URLS[group]:
        try:
            r=json.loads(request(url).decode('utf-8-sig'))
            if not isinstance(r,list) or len(r)<100:raise ValueError('group response too small')
            return r,{'url':url,'retrieval':'live HTTP at program run'}
        except Exception as e:errs.append(f'{url}: {e}')
    raise RuntimeError(f'{group} 下载失败。请下载官方 JSON 到本地，再通过 --{group.lower()}-omm 提供。\n'+'\n'.join(errs))

def get_identities(path,offline):
    if path:
        html=Path(path).read_text(encoding='utf-8-sig')
        return extract_gen1_index(html),path
    if offline:raise RuntimeError('--no-network 模式下需提供 --starlink-index')
    html=request(INDEX_URL).decode('utf-8-sig','replace')
    return extract_gen1_index(html),INDEX_URL

def validate(records):
    clean=[];dups=0;invalid=0;ids=set()
    for a in records:
        if not isinstance(a,dict) or any(k not in a or a[k] is None for k in REQUIRED):
            invalid+=1;continue
        try:
            sid=int(a['NORAD_CAT_ID'])
            for fld in ['MEAN_MOTION','ECCENTRICITY','INCLINATION','RA_OF_ASC_NODE','ARG_OF_PERICENTER','MEAN_ANOMALY']:
                float(a[fld])
            datetime.fromisoformat(str(a['EPOCH']).replace('Z','+00:00'))
        except (ValueError,TypeError):invalid+=1;continue
        if sid in ids:dups+=1;continue
        ids.add(sid);clean.append(a)
    return clean,{'invalid':invalid,'duplicate_norad':dups}

def select_starlink(records,identities):
    result=[];rejected=Counter()
    for rec in records:
        m=re.fullmatch(r'STARLINK[- ](\d{3,6})',str(rec['OBJECT_NAME']),re.I)
        if not m:rejected['other_names']+=1;continue
        version=identities.get(int(m.group(1)))
        if not version:rejected['not_in_v1_0_v1_5_identity_catalog']+=1;continue
        inc=float(rec['INCLINATION'])
        if 50<=inc<=56:family='53_degree'
        elif 68<=inc<=72:family='70_degree'
        elif 95<=inc<=100:family='97_degree'
        elif 40<=inc<=46:
            rejected['43_degree_Gen2_group5_V1_5']+=1;continue
        else:rejected['ambiguous_inclination']+=1;continue
        a=dict(rec);a['GENERATION']='Gen1 spacecraft V1.0/V1.5, non-43deg shell';a['VERSION']=version
        a['ORBIT_FAMILY']=family;a['SERVICE_OPERATION_STATUS']='not verified by GP record'
        result.append(a)
    return result,dict(rejected)

def select_oneweb(records):
    return [dict(x,GENERATION='OneWeb Gen1 group',SERVICE_OPERATION_STATUS='not verified by GP record')
            for x in records if str(x['OBJECT_NAME']).upper().startswith('ONEWEB')]

def select_geo(records):
    # GEO GROUP is a general satellite-track group, not the subset of GSO-FSS authorized on the target band.
    a=[]
    for x in records:
        obj=dict(x);obj['FSS_SERVICE_CLASS_VERIFIED']=False
        obj['BAND_17_8_18_6_GHZ_VERIFIED']=False
        obj['INCLUDE_AS_PROTECTED_GSO']=int(x['NORAD_CAT_ID'])==49332
        obj['NOTE']='Orbit-only candidate; confirm FSS protection and frequency via licensing before using.'
        if int(x['NORAD_CAT_ID'])==49332:
            obj['FSS_SERVICE_CLASS_VERIFIED']=True;obj['BAND_17_8_18_6_GHZ_VERIFIED']=True
            obj['NOTE']='SES-17 example; frequency coverage based on FCC public authorization, final EPFD protection criterion still requires independent verification.'
        a.append(obj)
    return a

def summary(records):
    ep=sorted(x['EPOCH'] for x in records)
    return {'count':len(records),'epoch_earliest_utc':ep[0] if ep else None,'epoch_latest_utc':ep[-1] if ep else None,
            'norad_unique':len({int(x['NORAD_CAT_ID']) for x in records})}

def generate(out,system,selected,source,gateways,details):
    obj={'schema_version':'2.0', 'generated_utc':datetime.now(timezone.utc).isoformat(),
         'system':system,'catalog_status':'complete_import_from_current_source',
         'orbit_format':'CCSDS OMM/GP JSON (SGP4-compatible)',
         'source':source,'catalog_summary':summary(selected),'selection_policy':details,
         'antenna_counts_for_study':[4,8,16],'study_band_ghz':[17.8,18.6],
         'study_band_note':'Study assumption; GP elements do not certify frequency or operational state.',
         'ground_stations':gateways,'satellites':sorted(selected,key=lambda x:int(x['NORAD_CAT_ID']))}
    tmp=out.with_suffix(out.suffix+'.tmp')
    with tmp.open('w',encoding='utf-8') as f:json.dump(obj,f,indent=2,ensure_ascii=False)
    os.replace(tmp,out)
    return obj

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output-dir',type=Path,default=HERE)
    p.add_argument('--starlink-omm');p.add_argument('--oneweb-omm');p.add_argument('--geo-omm')
    p.add_argument('--starlink-index',help='Locally saved HTML from Jonathan McDowell Starlink starindex.html')
    p.add_argument('--no-network',action='store_true')
    args=p.parse_args();args.output_dir.mkdir(parents=True,exist_ok=True)
    try:
        s,ss=acquire('STARLINK',args.starlink_omm,args.no_network)
        o,osrc=acquire('ONEWEB',args.oneweb_omm,args.no_network)
        g,gs=acquire('GEO',args.geo_omm,args.no_network)
        sid,identity_source=get_identities(args.starlink_index,args.no_network)
        s,sv=validate(s);o,ov=validate(o);g,gv=validate(g)
        sl,rejections=select_starlink(s,sid)
        ow=select_oneweb(o)
        geo=select_geo(g)
        if len(sl)<900 or len(ow)<400 or len(geo)<300:
            raise ValueError(f'卫星目录数异常 Starlink={len(sl)}, OneWeb={len(ow)}, GEO={len(geo)}。拒绝覆盖原文件。')
        bases={name:load_local(HERE/name) for name in ('Starlink_Gen1_orbit_with_real_gateways.json','OneWeb_orbit_with_real_gateways.json')}
        sgw=bases['Starlink_Gen1_orbit_with_real_gateways.json']['gateway_sites'];ogw=bases['OneWeb_orbit_with_real_gateways.json']['gateway_sites']
        plans=[('Starlink_Gen1_constellation.json','Starlink Gen1',sl,ss,sgw,{'identity_source':identity_source,'rule':'V1.0/V1.5 identity by JSR + non-43 degree orbit families', 'rejected':rejections,'input_validation':sv}),
               ('OneWeb_constellation.json','OneWeb Gen1',ow,osrc,ogw,{'rule':'CelesTrak ONEWEB group', 'input_validation':ov}),
               ('GSO_constellation.json','GSO/GEO candidate catalogue',geo,gs,[],{'rule':'CelesTrak GEO group; SES-17 is an example with separate public service parameters, other records require band verification','input_validation':gv})]
        for filename,system,selected,src,ground,detail in plans:
            data=generate(args.output_dir/filename,system,selected,src,ground,detail)
            print(f'{filename}: {data["catalog_summary"]["count"]} entries, latest EPOCH {data["catalog_summary"]["epoch_latest_utc"]}')
        print('SUCCESS. All three constellation JSON files updated.')
    except Exception as e:
        print('ERROR:',e,file=sys.stderr);return 1
    return 0

if __name__=='__main__':sys.exit(main())
